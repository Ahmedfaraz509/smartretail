/* Stock alerts management */
run(async()=>{
 const A=await loadAlerts();
 content.innerHTML=`<h4 class="fw-bold mb-3">Stock Alerts</h4><div class="row g-3 mb-3" id="k"></div><div class="cardx"><div class="row g-2 mb-3"><div class="col-md-4"><select id="fs" class="form-select"><option value="">All statuses</option><option>Active</option><option>Resolved</option><option>Dismissed</option></select></div></div><div id="tb"></div></div>`;
 const kp=()=>k.innerHTML=each([['exclamation-octagon','Critical',A.filter(a=>a.severity=='Critical'&&a.status=='Active').length,'danger'],['exclamation-triangle','High',A.filter(a=>a.severity=='High'&&a.status=='Active').length,'warning'],['info-circle','Medium',A.filter(a=>a.severity=='Medium'&&a.status=='Active').length,'primary'],['check-circle','Resolved',A.filter(a=>a.status=='Resolved').length,'success']],x=>`<div class="col-6 col-xl-3">${kpi(x[0],x[1],x[2],null,x[3])}</div>`);kp();
 const t=dt('#tb',{rows:A,size:5,cols:[{t:'Product',k:'product',r:x=>`<b>${x.product}</b>`},{t:'Alert Type',k:'type',r:x=>`${badge(x.severity)} ${x.type}`},{t:'Current Stock',k:'stock'},{t:'Predicted Demand',k:'predicted'},{t:'Hype Score',k:'hype'},{t:'Message',r:x=>`<div style="min-width:220px;font-size:.85rem">${x.message}</div>`},{t:'Status',k:'status',r:x=>badge(x.status)},{t:'Created',k:'created'},
  {t:'Action',r:x=>`<div class="btn-group btn-group-sm" data-id="${x.id}"><button class="btn btn-outline-secondary" data-a="v" title="View"><i class="bi bi-eye"></i></button><button class="btn btn-outline-danger" data-a="d" title="Dismiss" ${x.status!='Active'?'disabled':''}><i class="bi bi-x-lg"></i></button><button class="btn btn-outline-success" data-a="r" title="Mark Resolved" ${x.status!='Active'?'disabled':''}><i class="bi bi-check-lg"></i></button></div>`}]});
 fs.onchange=()=>t.set(x=>!fs.value||x.status==fs.value);
 tb.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=A.find(x=>x.id==b.parentNode.dataset.id),done=(s,m,c)=>{a.status=s;t.data(A);kp();toast(m,c)};
  if(b.dataset.a=='v')modalBox(a.type+': '+a.product,`<p>${a.message}</p><div class="stat"><span>Stock</span><b>${a.stock}</b></div><div class="stat"><span>Predicted demand</span><b>${a.predicted}</b></div><div class="stat"><span>Hype</span><b>${a.hype}</b></div>`);
  if(b.dataset.a=='d')modalBox('Dismiss alert',`Dismiss the alert for <b>${a.product}</b>?`,()=>done('Dismissed','Alert dismissed','secondary'));
  if(b.dataset.a=='r')done('Resolved','Alert marked as resolved')});
});
