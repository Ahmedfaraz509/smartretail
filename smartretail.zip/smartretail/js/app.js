/* SmartRetail core: API layer, layout injection, shared helpers */
// ---- API layer: replace values with '/api/products' etc. when the Python backend is ready ----
const API={products:'data/products.json',inventory:'data/inventory.json',sales:'data/sales.json',social:'data/social-posts.json',sentiment:'data/sentiment.json',trends:'data/trends.json',alerts:'data/alerts.json'};
const get=async k=>{const r=await fetch(API[k]);if(!r.ok)throw new Error(k+' request failed ('+r.status+')');return r.json()};
const loadProducts=()=>get('products'),loadInventory=()=>get('inventory'),loadSales=()=>get('sales'),loadSocialPosts=()=>get('social'),loadSentiment=()=>get('sentiment'),loadTrends=()=>get('trends'),loadAlerts=()=>get('alerts');

// ---- helpers ----
const PAGE=document.body.dataset.page,content=document.getElementById('content');
const C={p:'#2563EB',s:'#16A34A',w:'#F59E0B',d:'#DC2626',g:'#94A3B8'};
const fmt=n=>'Rs. '+Number(n).toLocaleString(),sum=(a,k)=>a.reduce((s,x)=>s+x[k],0),each=(a,f)=>a.map(f).join('');
const stockStatus=(s,r)=>s<=0?'Out of Stock':s<=r/2?'Critical':s<r?'Low Stock':'In Stock';
const lvl=r=>r>=75?'High':r>=40?'Medium':'Low';
const suggest=(p,d)=>Math.round(p*(1+d*.0022)/5)*5; // simulated pricing rule (front-end demo only)
const BC={'In Stock':'success','Low Stock':'warning','Critical':'danger','Out of Stock':'dark',Positive:'success',Neutral:'secondary',Negative:'danger',Active:'danger',Resolved:'success',Dismissed:'secondary',High:'danger',Medium:'warning',Low:'success',Rising:'success',Falling:'danger',Stable:'secondary'};
const badge=t=>`<span class="badge soft-${BC[t]||'primary'}">${t}</span>`;
const trendIcon=t=>`<i class="bi bi-${{Rising:'arrow-up-right text-success',Falling:'arrow-down-right text-danger',Stable:'arrow-right text-secondary'}[t]}"></i> ${t}`;
const kpi=(ic,l,v,ch,c='primary')=>`<div class="cardx kpi"><div class="ic soft-${c}"><i class="bi bi-${ic}"></i></div><div><small>${l}</small><h4>${v}</h4>${ch==null?'':`<small class="${ch>=0?'up':'down'}"><i class="bi bi-caret-${ch>=0?'up':'down'}-fill"></i> ${Math.abs(ch)}%</small>`}</div></div>`;
const card=(t,id)=>`<div class="cardx"><h6>${t}</h6><div class="cbox"><canvas id="${id}"></canvas></div></div>`;
const chart=(id,type,data,opt={})=>{Chart.getChart(id)?.destroy();return new Chart(document.getElementById(id),{type,data,options:{responsive:true,maintainAspectRatio:false,animation:{duration:900},...opt}})};
const run=fn=>{content.innerHTML='<div class="loader"><div class="spinner-border text-primary"></div></div>';fn().catch(fail)};
const fail=e=>{content.innerHTML=`<div class="empty"><i class="bi bi-exclamation-triangle text-danger"></i><h6>Could not load data</h6><p>${e.message}. Serve the folder with a local server (python -m http.server) or check your API.</p><button class="btn btn-primary">Retry</button></div>`;content.querySelector('button').onclick=()=>location.reload()};
function csv(name,rows){if(!rows.length)return toast('Nothing to export','warning');const k=Object.keys(rows[0]);const t=[k.join(','),...rows.map(r=>k.map(c=>`"${String(r[c]).replace(/"/g,'""')}"`).join(','))].join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv'}));a.download=name+'.csv';a.click()}

// ---- reusable data table: search, sort, pagination, empty state ----
const TABLES=[];
function dt(el,{cols,rows,size=6}){
 const box=typeof el=='string'?document.querySelector(el):el;let q='',sk=null,dir=1,pg=1,ext=()=>true;
 const draw=()=>{let r=rows.filter(x=>ext(x)&&JSON.stringify(x).toLowerCase().includes(q));
  if(sk)r.sort((a,b)=>(a[sk]>b[sk]?1:-1)*dir);
  const pages=Math.max(1,Math.ceil(r.length/size));pg=Math.min(pg,pages);const s=r.slice((pg-1)*size,pg*size);
  box.innerHTML=`<div class="table-responsive"><table class="table align-middle"><thead><tr>${each(cols,c=>`<th data-k="${c.k||''}">${c.t}${c.k?' <i class="bi bi-arrow-down-up small"></i>':''}</th>`)}</tr></thead><tbody>${s.length?each(s,x=>`<tr>${each(cols,c=>`<td>${c.r?c.r(x):x[c.k]}</td>`)}</tr>`):`<tr><td colspan="${cols.length}"><div class="empty"><i class="bi bi-inbox"></i><p>No records found</p></div></td></tr>`}</tbody></table></div>
  <div class="pager"><small>${r.length} records</small><div class="btn-group btn-group-sm"><button class="btn btn-outline-secondary" data-p="${pg-1}" ${pg<2?'disabled':''}>&lsaquo;</button><span class="btn btn-outline-secondary disabled">${pg}/${pages}</span><button class="btn btn-outline-secondary" data-p="${pg+1}" ${pg>=pages?'disabled':''}>&rsaquo;</button></div></div>`};
 box.addEventListener('click',e=>{const th=e.target.closest('th[data-k]'),b=e.target.closest('[data-p]');
  if(th&&th.dataset.k){dir=sk==th.dataset.k?-dir:1;sk=th.dataset.k;draw()}if(b){pg=+b.dataset.p;draw()}});
 const api={set(f){ext=f;pg=1;draw()},data(r){rows=r;draw()},search(v){q=v.toLowerCase();pg=1;draw()}};TABLES.push(api);draw();return api}

// ---- toast + modal helpers ----
function toast(msg,type='success'){const t=document.createElement('div');t.className=`toast align-items-center text-bg-${type} border-0`;t.innerHTML=`<div class="d-flex"><div class="toast-body">${msg}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;document.getElementById('toasts').append(t);const b=new bootstrap.Toast(t,{delay:3000});t.addEventListener('hidden.bs.toast',()=>t.remove());b.show()}
function modalBox(title,html,cb){const m=document.getElementById('mbox');m.querySelector('h5').textContent=title;m.querySelector('.modal-body').innerHTML=html;const ok=m.querySelector('.btn-primary');ok.style.display=cb?'':'none';ok.onclick=()=>{bootstrap.Modal.getInstance(m).hide();cb&&cb()};bootstrap.Modal.getOrCreateInstance(m).show()}

// ---- layout injection (sidebar + topbar shared by every page) ----
const NAV=[['index','Dashboard','speedometer2'],['products','Products','box-seam'],['inventory','Inventory','boxes'],['sales','Sales','cart'],['social-trends','Social Trends','megaphone'],['sentiment','Sentiment Analysis','emoji-smile'],['trend-analysis','Trend & Hype','graph-up-arrow'],['stock-alerts','Stock Alerts','bell'],['dynamic-pricing','Dynamic Pricing','currency-exchange'],['reports','Reports','file-earmark-bar-graph'],['settings','Settings','gear']];
const title=NAV.find(n=>n[0]==PAGE)[1];
const main=document.createElement('div');main.className='main';
main.innerHTML=`<header class="topbar"><button id="menuBtn" class="icon-btn"><i class="bi bi-list"></i></button><div class="me-auto"><h5>${title}</h5><div class="crumb">SmartRetail / ${title}</div></div>
<div class="search"><i class="bi bi-search"></i><input id="gSearch" placeholder="Search..."></div>
<div class="dropdown"><button class="icon-btn position-relative" data-bs-toggle="dropdown"><i class="bi bi-bell"></i><span id="nBadge" class="badge bg-danger">0</span></button><ul id="nList" class="dropdown-menu dropdown-menu-end p-2" style="min-width:290px"></ul></div>
<button id="themeBtn" class="icon-btn"><i class="bi bi-moon"></i></button>
<div class="dropdown"><button class="icon-btn" data-bs-toggle="dropdown"><i class="bi bi-person-circle"></i></button><ul class="dropdown-menu dropdown-menu-end"><li class="px-3 py-1"><b>Admin</b><br><small class="text-muted">Retail Manager</small></li><li><hr class="dropdown-divider"></li><li><a class="dropdown-item" href="settings.html">Settings</a></li><li><a class="dropdown-item" id="logout" href="#">Logout</a></li></ul></div></header><div class="page"></div>`;
document.body.prepend(main);main.querySelector('.page').append(content);
document.body.insertAdjacentHTML('afterbegin',`<aside class="sidebar"><div class="brand"><i class="bi bi-cpu-fill"></i><div><b>SmartRetail</b><small>AI-Powered Retail Intelligence</small></div></div><nav>${each(NAV,n=>`<a href="${n[0]}.html" class="${n[0]==PAGE?'active':''}"><i class="bi bi-${n[2]}"></i><span>${n[1]}</span></a>`)}</nav><div class="side-foot"><div class="d-flex gap-2 align-items-center mb-2"><span class="avatar">A</span><div><b>Admin</b><small>Retail Manager</small></div></div><small><i class="bi bi-circle-fill text-success"></i> System Status: Online</small></div></aside><div class="backdrop"></div>
<div id="toasts" class="toast-container position-fixed bottom-0 end-0 p-3"></div>
<div class="modal fade" id="mbox"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5></h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Confirm</button></div></div></div></div>`);

// ---- behaviours: sidebar, theme, search, notifications ----
document.getElementById('menuBtn').onclick=()=>document.body.classList.toggle(innerWidth<992?'menu-open':'collapsed');
document.querySelector('.backdrop').onclick=()=>document.body.classList.remove('menu-open');
const setTheme=t=>{document.documentElement.dataset.bsTheme=t;localStorage.theme=t;Chart.defaults.color=t=='dark'?'#9CA3AF':'#6B7280';document.querySelector('#themeBtn i').className='bi bi-'+(t=='dark'?'sun':'moon')};
setTheme(localStorage.theme||'light');
document.getElementById('themeBtn').onclick=()=>{setTheme(localStorage.theme=='dark'?'light':'dark');document.getElementById('darkSw')&&(darkSw.checked=localStorage.theme=='dark')};
document.getElementById('gSearch').oninput=e=>TABLES.forEach(t=>t.search(e.target.value));
document.getElementById('logout').onclick=e=>{e.preventDefault();toast('Logged out (demo)','secondary')};
loadAlerts().then(a=>{const x=a.filter(i=>i.status=='Active');nBadge.textContent=x.length;nList.innerHTML=each(x,i=>`<li class="p-2 small border-bottom"><b>${i.product}</b> ${badge(i.severity)}<br><span class="text-muted">${i.message}</span></li>`)}).catch(()=>nList.innerHTML='<li class="p-2 small">Notifications unavailable</li>');

// ---- Settings page (no dedicated JS file in the structure) ----
if(PAGE=='settings'){
 const sw=(id,l,on=1)=>`<div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" id="${id}" ${on?'checked':''}><label class="form-check-label" for="${id}">${l}</label></div>`;
 content.innerHTML=`<div class="row g-3"><div class="col-md-6"><div class="cardx"><h6>Profile Settings</h6><input class="form-control mb-2" value="Admin"><input class="form-control mb-2" value="admin@smartretail.pk"><input class="form-control" value="Retail Manager"></div></div>
 <div class="col-md-6"><div class="cardx"><h6>Notification Settings</h6>${sw('s1','Email Notifications')}${sw('s2','Stock Alerts')}${sw('s3','Trend Alerts')}</div></div>
 <div class="col-md-6"><div class="cardx"><h6>Dashboard Settings</h6>${sw('s4','Auto Refresh')}${sw('s5','Show Charts')}</div></div>
 <div class="col-md-6"><div class="cardx"><h6>System Settings</h6>${sw('darkSw','Dark Mode',localStorage.theme=='dark')}<small class="text-muted">API source: data/*.json (switch to /api/* in js/app.js)</small></div></div></div><button class="btn btn-primary mt-3" id="saveBtn">Save Settings</button>`;
 darkSw.onchange=()=>setTheme(darkSw.checked?'dark':'light');saveBtn.onclick=()=>toast('Settings saved');
}
