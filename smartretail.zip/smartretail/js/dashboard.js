/* Dashboard: KPIs, charts, social trends table, alert panel */
const ALERT_ICON={'Low Stock':['exclamation-triangle','warning'],'High Demand':['lightning-charge','danger'],'Trending Product':['fire','primary'],'Stock-Out Risk':['x-octagon','danger']};
run(async()=>{
 const [p,inv,sales,t,al]=await Promise.all([loadProducts(),loadInventory(),loadSales(),loadTrends(),loadAlerts()]);
 const act=al.filter(a=>a.status=='Active');
 content.innerHTML=`<h4 class="fw-bold mb-0">Good Morning, Admin</h4><p class="text-muted">Here's what's happening with your retail business today.</p>
 <div class="row g-3 mb-3">${each([['box-seam','Total Products',p.length,4],['boxes','Current Inventory',sum(inv,'stock')+' units',-2.1,'warning'],['cash-stack',"Today's Sales",fmt(8450),12.5,'success'],['megaphone','Social Mentions','1,248',18.2],['fire','Average Hype Score',(sum(t,'hype')/t.length).toFixed(1),6.4,'danger'],['bell','Active Stock Alerts',act.length,-8,'warning']],k=>`<div class="col-6 col-xl-4">${kpi(...k)}</div>`)}</div>
 <div class="row g-3 mb-3"><div class="col-lg-8">${card('Sales Overview (7 days)','c1')}</div><div class="col-lg-4">${card('Sentiment Distribution','c2')}</div>
 <div class="col-lg-6">${card('Inventory Overview','c3')}</div><div class="col-lg-6">${card('Social Media Hype Score','c4')}</div><div class="col-12">${card('Stock Risk %','c5')}</div></div>
 <div class="row g-3"><div class="col-xl-8"><div class="cardx"><h6>Recent Social Trends</h6><div id="tt"></div></div></div>
 <div class="col-xl-4"><div class="cardx"><h6>Stock Alerts</h6>${each(act,a=>{const i=ALERT_ICON[a.type];return `<div class="alert-item"><div class="ic soft-${i[1]}"><i class="bi bi-${i[0]}"></i></div><div><b>${a.type}</b> ${badge(a.severity)}<p>${a.message}</p><a href="products.html" class="btn btn-sm btn-outline-primary">View Product</a> <a href="inventory.html" class="btn btn-sm btn-light">View Inventory</a></div></div>`})}</div></div></div>`;
 const days=[...new Set(sales.map(s=>s.date))].sort();
 chart('c1','line',{labels:days.map(d=>d.slice(5)),datasets:[{label:'Sales (Rs.)',data:days.map(d=>sum(sales.filter(s=>s.date==d).map(s=>({v:s.qty*s.price})),'v')),borderColor:C.p,backgroundColor:'rgba(37,99,235,.12)',fill:true,tension:.4}]});
 const pos=sum(t,'positive'),neg=sum(t,'negative');
 chart('c2','doughnut',{labels:['Positive','Neutral','Negative'],datasets:[{data:[pos,sum(t,'mentions')-pos-neg,neg],backgroundColor:[C.s,C.g,C.d]}]},{cutout:'68%'});
 chart('c3','bar',{labels:inv.map(i=>i.product),datasets:[{label:'Current Stock',data:inv.map(i=>i.stock),backgroundColor:C.p,borderRadius:6},{label:'Reorder Level',data:inv.map(i=>i.reorder),backgroundColor:C.w,borderRadius:6}]});
 chart('c4','line',{labels:days.map(d=>d.slice(5)),datasets:[{label:'Avg Hype',data:t[0].history.map((_,i)=>+(sum(t.map(x=>({v:x.history[i]})),'v')/t.length).toFixed(1)),borderColor:C.d,tension:.4}]});
 chart('c5','bar',{labels:t.map(x=>x.product),datasets:[{label:'Risk %',data:t.map(x=>x.risk),backgroundColor:t.map(x=>x.risk>=75?C.d:x.risk>=40?C.w:C.s),borderRadius:6}]},{indexAxis:'y'});
 dt('#tt',{size:5,rows:t,cols:[{t:'Product',k:'product'},{t:'Mentions',k:'mentions'},{t:'Positive',k:'positive'},{t:'Negative',k:'negative'},{t:'Hype Score',k:'hype'},{t:'Trend',k:'trend',r:x=>trendIcon(x.trend)}]});
});
