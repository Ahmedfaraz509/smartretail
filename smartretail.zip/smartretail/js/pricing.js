/* Dynamic pricing: FRONT-END SIMULATION ONLY (rule in app.js -> suggest()) */
run(async()=>{
 const [P,T,I]=await Promise.all([loadProducts(),loadTrends(),loadInventory()]);
 const reason=t=>t.demand>=25?'High social media demand':t.demand>0?'Moderate positive demand':t.demand<0?'Falling interest, price slightly reduced':'Stable demand';
 content.innerHTML=`<div class="alert alert-info"><i class="bi bi-info-circle"></i> Simulation only: suggested prices come from a demo rule, not a trained model.</div><div class="row g-3">${each(P,p=>{const t=T.find(x=>x.product==p.name),i=I.find(x=>x.product==p.name),sp=suggest(p.price,t.demand),ch=((sp-p.price)/p.price*100).toFixed(1);
 return `<div class="col-md-6 col-xl-4"><div class="cardx" data-n="${p.name}"><div class="d-flex justify-content-between mb-2"><h6 class="mb-0">${p.name}</h6><span class="badge soft-${ch>=0?'success':'danger'}">${ch>0?'+':''}${ch}%</span></div>
 <div class="row text-center mb-2"><div class="col"><small class="text-muted">Current</small><div class="price-big">${fmt(p.price)}</div></div><div class="col"><small class="text-muted">Suggested</small><div class="price-big text-primary">${fmt(sp)}</div></div></div>
 <div class="stat"><span>Demand</span><b>${t.demand>0?'+':''}${t.demand}%</b></div><div class="stat"><span>Hype Score</span><b>${t.hype}</b></div><div class="stat"><span>Stock Level</span><b>${i.stock} units</b></div><p class="small text-muted my-2"><b>Reason:</b> ${reason(t)}</p>
 <div class="d-flex gap-2"><button class="btn btn-sm btn-primary flex-fill" data-a="ok">Approve Price</button><button class="btn btn-sm btn-outline-danger" data-a="no">Reject</button><button class="btn btn-sm btn-light" data-a="an">View Analysis</button></div></div></div>`})}</div>`;
 content.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const c=b.closest('.cardx'),n=c.dataset.n,t=T.find(x=>x.product==n);
  if(b.dataset.a=='an')return modalBox('Pricing analysis: '+n,`<div class="stat"><span>Mentions</span><b>${t.mentions}</b></div><div class="stat"><span>Hype band</span><b>${band(t.hype)[0]}</b></div><div class="stat"><span>Stock risk</span><b>${t.risk}% (${lvl(t.risk)})</b></div><p class="small text-muted mt-2">Rule: suggested = price x (1 + demand% x 0.22), rounded to Rs. 5.</p>`);
  c.querySelectorAll('[data-a]').forEach(x=>x.disabled=true);
  b.dataset.a=='ok'?toast('Price recommendation approved.'):toast('Price recommendation rejected.','secondary')});
});
