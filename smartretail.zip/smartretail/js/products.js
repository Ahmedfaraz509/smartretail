/* Products: CRUD (in-memory), filters, validation, CSV export */
run(async()=>{
 let P=await loadProducts(),editId=null;
 const uniq=k=>[...new Set(P.map(p=>p[k]))];
 content.innerHTML=`<div class="d-flex flex-wrap gap-2 mb-3 align-items-center"><h4 class="fw-bold me-auto mb-0">Products</h4><button id="exp" class="btn btn-outline-secondary"><i class="bi bi-download"></i> Export</button><button id="add" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add Product</button></div>
 <div class="cardx"><div class="row g-2 mb-3"><div class="col-md-4"><select id="fc" class="form-select"><option value="">All Categories</option>${each(uniq('category'),x=>`<option>${x}</option>`)}</select></div><div class="col-md-4"><select id="fb" class="form-select"><option value="">All Brands</option>${each(uniq('brand'),x=>`<option>${x}</option>`)}</select></div><div class="col-md-4"><select id="fs" class="form-select"><option value="">All Stock Status</option><option>In Stock</option><option>Low Stock</option><option>Critical</option><option>Out of Stock</option></select></div></div><div id="tb"></div></div>
 <div class="modal fade" id="pm"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 id="pt"></h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><form id="pf" novalidate>${each([['name','Product Name','text'],['category','Category','text'],['brand','Brand','text'],['price','Price (Rs.)','number'],['stock','Stock','number'],['reorder','Reorder Level','number']],f=>`<div class="mb-2"><label class="form-label">${f[1]}</label><input class="form-control" name="${f[0]}" type="${f[2]}"><div class="invalid-feedback">Please enter a valid value.</div></div>`)}</form></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button id="ps" class="btn btn-primary">Save Product</button></div></div></div></div>`;
 const t=dt('#tb',{rows:P,cols:[{t:'ID',k:'id'},{t:'Product',k:'name',r:x=>`<b>${x.name}</b>`},{t:'Category',k:'category'},{t:'Brand',k:'brand'},{t:'Price',k:'price',r:x=>fmt(x.price)},{t:'Stock',k:'stock'},{t:'Reorder Level',k:'reorder'},{t:'Status',r:x=>badge(stockStatus(x.stock,x.reorder))},
  {t:'Actions',r:x=>`<div class="btn-group btn-group-sm" data-id="${x.id}"><button class="btn btn-outline-secondary" data-a="view"><i class="bi bi-eye"></i></button><button class="btn btn-outline-primary" data-a="edit"><i class="bi bi-pencil"></i></button><button class="btn btn-outline-danger" data-a="del"><i class="bi bi-trash"></i></button></div>`}]});
 const flt=()=>t.set(x=>(!fc.value||x.category==fc.value)&&(!fb.value||x.brand==fb.value)&&(!fs.value||stockStatus(x.stock,x.reorder)==fs.value));
 [fc,fb,fs].forEach(s=>s.onchange=flt);
 const M=bootstrap.Modal.getOrCreateInstance(pm);
 const open=(mode,p={})=>{pf.reset();pf.classList.remove('was-validated');editId=mode=='add'?null:p.id;pt.textContent={add:'Add Product',edit:'Edit Product',view:'Product Details'}[mode];
  [...pf.elements].forEach(e=>{e.value=p[e.name]??'';e.disabled=mode=='view'});ps.style.display=mode=='view'?'none':'';M.show()};
 add.onclick=()=>open('add');exp.onclick=()=>csv('products',P);
 tb.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const p=P.find(x=>x.id==b.parentNode.dataset.id);
  if(b.dataset.a=='del')modalBox('Delete product',`Delete <b>${p.name}</b>? This cannot be undone.`,()=>{P=P.filter(x=>x.id!=p.id);t.data(P);toast('Product deleted','danger')});else open(b.dataset.a,p)});
 ps.onclick=()=>{const f=pf.elements;let ok=true;
  [...f].forEach(e=>{const bad=!e.value.trim()||(e.type=='number'&&(e.value<0||(e.name=='price'&&e.value<=0)));e.classList.toggle('is-invalid',bad);if(bad)ok=false});
  if(!ok)return;const o={name:f.name.value.trim(),category:f.category.value.trim(),brand:f.brand.value.trim(),price:+f.price.value,stock:+f.stock.value,reorder:+f.reorder.value};
  if(editId){Object.assign(P.find(x=>x.id==editId),o)}else P.push({id:Math.max(0,...P.map(x=>x.id))+1,...o});
  t.data(P);M.hide();toast(editId?'Product updated':'Product added')};
});
