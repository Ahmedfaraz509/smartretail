/* Sales analytics: filters, KPIs, charts, table */
run(async()=>{
 const S=(await loadSales()).map(s=>({...s,total:s.qty*s.price})),prods=[...new Set(S.map(s=>s.product))];
 content.innerHTML=`<h4 class="fw-bold mb-3">Sales</h4><div class="row g-3 mb-3" id="k"></div><div class="row g-3 mb-3"><div class="col-lg-6">${card('Sales by Product','c1')}</div><div class="col-lg-6">${card('Sales over Time','c2')}</div></div>
 <div class="cardx"><div class="row g-2 mb-3"><div class="col-md-4"><select id="fp" class="form-select"><option value="">All products</option>${each(prods,x=>`<option>${x}</option>`)}</select></div><div class="col-md-4"><input id="d1" type="date" class="form-control"></div><div class="col-md-4"><input id="d2" type="date" class="form-control"></div></div><div id="tb"></div></div>`;
 const t=dt('#tb',{rows:S,cols:[{t:'Sale ID',k:'id'},{t:'Product',k:'product'},{t:'Quantity',k:'qty'},{t:'Unit Price',k:'price',r:x=>fmt(x.price)},{t:'Total',k:'total',r:x=>`<b>${fmt(x.total)}</b>`},{t:'Date',k:'date'}]});
 const apply=()=>{const r=S.filter(s=>(!fp.value||s.product==fp.value)&&(!d1.value||s.date>=d1.value)&&(!d2.value||s.date<=d2.value));
  const tot=sum(r,'total'),by={},day={};r.forEach(s=>{by[s.product]=(by[s.product]||0)+s.total;day[s.date]=(day[s.date]||0)+s.total});
  const top=Object.entries(by).sort((a,b)=>b[1]-a[1])[0];
  k.innerHTML=each([['currency-dollar','Total Sales',fmt(tot),12,'success'],['bag-check','Units Sold',sum(r,'qty'),8],['receipt','Avg Order Value',fmt(r.length?Math.round(tot/r.length):0),3,'warning'],['trophy','Top Product',top?top[0]:'-',null,'danger']],x=>`<div class="col-6 col-xl-3">${kpi(...x)}</div>`);
  chart('c1','bar',{labels:Object.keys(by),datasets:[{label:'Revenue',data:Object.values(by),backgroundColor:C.p,borderRadius:6}]});
  chart('c2','line',{labels:Object.keys(day).sort().map(d=>d.slice(5)),datasets:[{label:'Sales',data:Object.keys(day).sort().map(d=>day[d]),borderColor:C.s,backgroundColor:'rgba(22,163,74,.12)',fill:true,tension:.4}]});
  t.data(r)};
 [fp,d1,d2].forEach(e=>e.onchange=apply);apply();
});
