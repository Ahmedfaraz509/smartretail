/* Sentiment analysis (NLP results) */
run(async()=>{
 const S=await loadSentiment(),n=s=>S.filter(x=>x.sentiment==s).length,pc=s=>Math.round(n(s)/S.length*100)+'%';
 content.innerHTML=`<h4 class="fw-bold mb-3">Sentiment Analysis</h4><div class="row g-3 mb-3">${each([['emoji-smile','Positive Sentiment',pc('Positive'),null,'success'],['emoji-neutral','Neutral Sentiment',pc('Neutral'),null,'secondary'],['emoji-frown','Negative Sentiment',pc('Negative'),null,'danger'],['speedometer','Avg Sentiment Score',(sum(S,'score')/S.length).toFixed(2)]],x=>`<div class="col-6 col-xl-3">${kpi(...x)}</div>`)}</div>
 <div class="row g-3"><div class="col-lg-4">${card('Sentiment Distribution','c1')}</div><div class="col-lg-8"><div class="cardx"><div class="btn-group mb-3" id="fb">${each(['All','Positive','Neutral','Negative'],x=>`<button class="btn btn-outline-primary btn-sm ${x=='All'?'active':''}">${x}</button>`)}</div><div id="tb"></div></div></div></div>`;
 chart('c1','doughnut',{labels:['Positive','Neutral','Negative'],datasets:[{data:[n('Positive'),n('Neutral'),n('Negative')],backgroundColor:[C.s,C.g,C.d]}]},{cutout:'65%'});
 const t=dt('#tb',{rows:S,size:5,cols:[{t:'Post',k:'post'},{t:'Product',k:'product'},{t:'Sentiment',k:'sentiment',r:x=>badge(x.sentiment)},{t:'Score',k:'score',r:x=>`<b class="${x.sentiment=='Positive'?'up':x.sentiment=='Negative'?'down':''}">${x.score}</b>`},{t:'Analyzed At',k:'analyzed'}]});
 fb.onclick=e=>{const b=e.target.closest('button');if(!b)return;fb.querySelectorAll('button').forEach(x=>x.classList.toggle('active',x==b));t.set(x=>b.textContent=='All'||x.sentiment==b.textContent)};
});
