/* Social media monitoring */
run(async()=>{
 const [P,T]=await Promise.all([loadSocialPosts(),loadTrends()]);const ico={'X / Twitter':'twitter-x','Instagram':'instagram','Facebook':'facebook'};
 content.innerHTML=`<h4 class="fw-bold mb-3">Social Media Trends</h4><div class="row g-3 mb-3">${each([['megaphone','Total Mentions','1,248',18.2],['fire','Trending Products',T.filter(x=>x.hype>=80).length,null,'danger'],['emoji-smile','Average Sentiment',(sum(P,'score')/P.length).toFixed(2),4.1,'success'],['lightning-charge','Average Hype Score',(sum(T,'hype')/T.length).toFixed(1),6.4,'warning']],x=>`<div class="col-6 col-xl-3">${kpi(...x)}</div>`)}</div>
 <div class="cardx"><div class="row g-2 mb-3"><div class="col-md-4"><select id="fpl" class="form-select"><option value="">All platforms</option>${each(Object.keys(ico),x=>`<option>${x}</option>`)}</select></div></div><div id="tb"></div></div>`;
 const t=dt('#tb',{rows:P,size:5,cols:[{t:'Platform',k:'platform',r:x=>`<i class="bi bi-${ico[x.platform]}"></i> ${x.platform}`},{t:'Product',k:'product'},{t:'Post',k:'post',r:x=>`<div style="min-width:240px">${x.post}</div>`},{t:'Author',k:'author'},{t:'Date',k:'date'},{t:'Sentiment',k:'sentiment',r:x=>badge(x.sentiment)},{t:'Score',k:'score'}]});
 fpl.onchange=()=>t.set(x=>!fpl.value||x.platform==fpl.value);
});
