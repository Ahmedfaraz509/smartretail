/* Trend & Hype intelligence */
const band=h=>h<=30?['Low','secondary']:h<=60?['Moderate','warning']:h<=80?['High','primary']:['Very High','danger'];
run(async()=>{
 const T=await loadTrends(),steps=[['megaphone','Social Mentions','primary'],['emoji-smile','Sentiment Analysis','success'],['fire','Hype Score','warning'],['graph-up-arrow','Demand Increase','primary'],['exclamation-triangle','Stock Risk','danger']];
 content.innerHTML=`<h4 class="fw-bold mb-3">Trend &amp; Hype Intelligence</h4>
 <div class="cardx mb-3"><div class="flow">${steps.map((s,i)=>`<div class="step soft-${s[2]}"><i class="bi bi-${s[0]}"></i> ${s[1]}</div>${i<4?'<i class="bi bi-arrow-right"></i>':''}`).join('')}</div></div>
 <div class="row g-3 mb-3">${each(T,x=>{const b=band(x.hype);return `<div class="col-md-6 col-xl-4"><div class="cardx"><div class="d-flex justify-content-between mb-2"><h6 class="mb-0">${x.product}</h6>${badge(x.trend)}</div>
 <div class="d-flex align-items-baseline gap-2 mb-2"><span class="price-big">${x.hype}</span><span class="badge soft-${b[1]}">${b[0]}</span></div>
 <div class="progress mb-2"><div class="progress-bar bg-${b[1]=='secondary'?'secondary':b[1]}" style="width:${x.hype}%"></div></div>
 <div class="stat"><span>Mentions</span><b>${x.mentions}</b></div><div class="stat"><span>Positive / Negative</span><b>${x.positive} / ${x.negative}</b></div><div class="stat"><span>Trend</span><b>${trendIcon(x.trend)}</b></div><div class="stat"><span>Demand Increase</span><b class="${x.demand>=0?'up':'down'}">${x.demand>0?'+':''}${x.demand}%</b></div><div class="stat"><span>Risk</span>${badge(lvl(x.risk))}</div></div></div>`})}</div>
 ${card('Hype Score Over Time','c1')}<div class="band"><span class="badge soft-secondary">0-30 Low</span><span class="badge soft-warning">31-60 Moderate</span><span class="badge soft-primary">61-80 High</span><span class="badge soft-danger">81-100 Very High</span></div>`;
 const cols=[C.p,C.s,C.w,C.d,C.g];
 chart('c1','line',{labels:['Day 1','Day 2','Day 3','Day 4','Day 5','Day 6','Today'],datasets:T.map((x,i)=>({label:x.product,data:x.history,borderColor:cols[i],tension:.4}))},{scales:{y:{min:0,max:100}}});
 document.querySelector('.cbox').style.height='340px';
});
